package ours;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;

import static java.lang.System.out;

public class ours {

    //初始阶段
    /*public static void setup(String pairingFile, String publicFile,String mskFile,String KGC_i) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        //设置KGC_A和KGC_B的主私钥
        Element s_i = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Properties mskProp = new Properties();  //定义一个对properties文件操作的对象
        mskProp.setProperty("s_"+KGC_i, Base64.getEncoder().encodeToString(s_i.toBytes()));//element和string类型之间的转换需要通过bytes
        storePropToFile(mskProp, mskFile);

        //设置主公钥
        Element BSN_A = bp.getZr().newRandomElement().getImmutable();
        Element P = bp.getG1().newRandomElement().getImmutable();
        Element P_pubi = P.powZn(s_i).getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        PubProp.setProperty("BSN_"+KGC_i, BSN_A.toString());
        PubProp.setProperty("P_pub_"+KGC_i, P_pubi.toString());
        storePropToFile(PubProp,publicFile);

    }  */

    public static void setup(String pairingFile, String publicFile,String mskFile,String KGC) {

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        storePropToFile(PubProp,publicFile);

        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置KGC的主私钥
        Element s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        mskProp.setProperty("s_"+KGC, Base64.getEncoder().encodeToString(s.toBytes()));//element和string类型之间的转换需要通过bytes
        storePropToFile(mskProp, mskFile);

        //设置主公钥
        Element P_pub = P.powZn(s).getImmutable();
        PubProp.setProperty("P_pub_"+KGC, P_pub.toString());
        storePropToFile(PubProp,publicFile);

    }


    //Registration阶段
    public static void Registration_RSU(String pairingFile,String publicFile,String pkFile,String skFile,String KGC,String RSU_i) throws NoSuchAlgorithmException {

        //获得KGC的公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);

        //为RSU生成公私钥
        Element x_Ri=bp.getZr().newRandomElement().getImmutable();
        Element X_Ri=P.powZn(x_Ri).getImmutable();
        Element r_Ri=bp.getZr().newRandomElement().getImmutable();
        Element R_Ri=P.powZn(r_Ri).getImmutable();
        byte[] bH1_i=sha1(P_pub.toString()+RSU_i+X_Ri.toString()+R_Ri.toString());
        Element H1_i=bp.getZr().newElementFromHash(bH1_i,0,bH1_i.length).getImmutable();
        Element d_Ri=r_Ri.powZn(P_pub.powZn(H1_i)).getImmutable();

        pkp.setProperty("X_"+RSU_i,X_Ri.toString());
        pkp.setProperty("R_"+RSU_i,R_Ri.toString());
        skp.setProperty("x_"+RSU_i,Base64.getEncoder().encodeToString(x_Ri.toBytes()));
        skp.setProperty("d_"+RSU_i,Base64.getEncoder().encodeToString(d_Ri.toBytes()));
        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);

    }

    public static void Registration_V(String pairingFile,String publicFile,String pkFile,String skFile,String KGC,String ID_i) throws NoSuchAlgorithmException {

        //获得KGC的公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);

        //为车辆生成公私钥
        Element x_i=bp.getZr().newRandomElement().getImmutable();
        Element X_i=P.powZn(x_i).getImmutable();
        Element r_i=bp.getZr().newRandomElement().getImmutable();
        Element R_i=P.powZn(r_i).getImmutable();
            //为车辆生成假名
        byte[] bID_i=ID_i.getBytes();
        byte[] bH0_i=sha1(P_pub.toString()+R_i.toString());
        int n = Math.max(bH0_i.length, bID_i.length);
        int m = Math.min(bH0_i.length, bID_i.length);
        byte[] bPID_i=new byte[n];
        for (int i=0;i<m;i++)
            bPID_i[i]= (byte) (bH0_i[i]^bID_i[i]);
       // Map<Element, byte[]> elementToByteArrayMap = new HashMap<>();
        Element PID_i=bp.getG1().newElementFromHash(bPID_i,0,bPID_i.length).getImmutable();
       // elementToByteArrayMap.put(PID_i, bPID_i); // 将 PID_i 和 bPID_i 关联起来
        pkp.setProperty("PID_"+ID_i,PID_i.toString());

        byte[] bH1_i=sha1(P_pub.toString()+ PID_i.toString()+X_i.toString()+R_i.toString());
        Element H1_i=bp.getZr().newElementFromHash(bH1_i,0,bH1_i.length).getImmutable();
        Element d_i=r_i.powZn(P_pub.powZn(H1_i));

        pkp.setProperty("X_"+ID_i,X_i.toString());
        pkp.setProperty("R_"+ID_i,R_i.toString());
        skp.setProperty("x_"+ID_i,Base64.getEncoder().encodeToString(x_i.toBytes()));
        skp.setProperty("d_"+ID_i,Base64.getEncoder().encodeToString(d_i.toBytes()));
        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);

    }
    public static void IdAuth_RSU_V_and_getCerti(String pairingFile,String publicFile,String pkFile,String skFile,String veriFile,String certiFile,String KGC,String RSU_i,String ID_i) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();


        Element RSUi=bp.getG1().newElementFromBytes(RSU_i.getBytes()).getImmutable();
        Properties pkp=loadPropFromFile(pkFile);
        //获取车辆假名
        String PID_istr=pkp.getProperty("PID_"+ID_i);//获取属性
        Element PID_i=bp.getG1().newElementFromBytes(PID_istr.getBytes()).getImmutable();//字符串转换为element

        //获取车辆和RSU公钥
        String X_istr=pkp.getProperty("X_"+ID_i);
        Element X_i=bp.getG1().newElementFromBytes(X_istr.getBytes()).getImmutable();
        String R_istr=pkp.getProperty("R_"+ID_i);
        Element R_i=bp.getG1().newElementFromBytes(R_istr.getBytes()).getImmutable();
        String X_Ristr=pkp.getProperty("X_"+RSU_i);
        Element X_Ri=bp.getG1().newElementFromBytes(X_Ristr.getBytes()).getImmutable();
        String R_Ristr=pkp.getProperty("R_"+RSU_i);
        Element R_Ri=bp.getG1().newElementFromBytes(R_Ristr.getBytes()).getImmutable();
        //获取车辆和RSU私钥
        Properties skp=loadPropFromFile(skFile);
        String x_istr=skp.getProperty("x_"+ID_i);
        Element x_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_istr)).getImmutable();
        String d_istr=skp.getProperty("d_"+ID_i);
        Element d_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_istr)).getImmutable();
        String x_Ristr=skp.getProperty("x_"+RSU_i);
        Element x_Ri=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_Ristr)).getImmutable();
        String d_Ristr=skp.getProperty("d_"+RSU_i);
        Element d_Ri=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_Ristr)).getImmutable();

        //Vi向RSU_i发消息
        Element t0_i=bp.getZr().newRandomElement().getImmutable();
        Element t1_i=bp.getZr().newRandomElement().getImmutable();
        Element T0_i=P.powZn(t0_i).getImmutable();
        Element T1_i=P.powZn(t1_i).getImmutable();
        byte[] bh1_Ri=sha1(P_pub.toString()+RSU_i+X_Ri.toString()+ R_Ri.toString());
        Element h1_Ri=bp.getZr().newElementFromHash(bh1_Ri,0,bh1_Ri.length).getImmutable();
        Element Q0_i= t0_i.powZn(X_Ri.add(R_Ri.add(P_pub.powZn(h1_Ri))));
        byte[] bhQ0_i=sha1(Q0_i.toString());
        Element hQ0_i=bp.getZr().newElementFromHash(bhQ0_i,0,bhQ0_i.length).getImmutable();
        Element temp0_i=PID_i.powZn(T1_i).getImmutable();
        byte[] btemp0_i=temp0_i.toBytes();
        int n = Math.max(bhQ0_i.length, btemp0_i.length);
        int m = Math.min(bhQ0_i.length, btemp0_i.length);
        byte[] bM0_i=new byte[n];
        for (int i=0;i<m;i++)
            bM0_i[i]= (byte) (bhQ0_i[i]^btemp0_i[i]);
        Element M0_i=bp.getZr().newElementFromHash(bM0_i,0,bM0_i.length).getImmutable();
        Element Gamma1_i=bp.getG1().newRandomElement().getImmutable();
        byte[] bh2_i=sha1(PID_i.toString()+M0_i.toString()+X_i.toString()+ R_i.toString()+T1_i.toString()+Gamma1_i.toString());
        Element h2_i=bp.getZr().newElementFromHash(bh2_i,0,bh2_i.length).getImmutable();
        byte[] bh3_i=sha2(PID_i.toString()+M0_i.toString()+X_i.toString()+ R_i.toString()+T1_i.toString()+Gamma1_i.toString());
        Element h3_i=bp.getZr().newElementFromHash(bh2_i,0,bh2_i.length).getImmutable();
        Element sigma_i= t1_i.add(h2_i.mul(x_i).add(h3_i.mul(d_i)));

        Properties verip=loadPropFromFile(veriFile);

        //RSU_i验证Vi的签名
        byte[] bh1_i=sha1(P_pub.toString()+ PID_i.toString()+X_i.toString()+R_i.toString());
        Element h1_i=bp.getZr().newElementFromHash(bh1_i,0,bh1_i.length).getImmutable();

        Element sigma_iP=P.powZn(sigma_i).getImmutable();
        Element sigmaiP=(T1_i.add(X_i.powZn(h2_i))).add((R_i.add(P_pub.powZn(h1_i))).powZn(h3_i)).getImmutable();

        if (sigma_iP.isEqual(sigmaiP)){
            //如果RSU_i验证成功
            //out.println("RSU验证V成功1");
        }
        else {
            out.println("RSU验证V失败");
        }
        //RSUi向Vi发消息
        Element t2_i=bp.getZr().newRandomElement().getImmutable();
        Element t3_i=bp.getZr().newRandomElement().getImmutable();
        Element T2_i=P.powZn(t0_i).getImmutable();
        Element T3_i=P.powZn(t1_i).getImmutable();
        Element Q1_i= (X_i.add(R_i.add(P_pub.powZn(h1_i)))).powZn(t2_i);
        byte[] bhQ1_i=sha1(Q0_i.toString());
        Element hQ1_i=bp.getZr().newElementFromHash(bhQ1_i,0,bhQ1_i.length).getImmutable();
        Element Di=bp.getG1().newRandomElement().getImmutable();
        Element texti=bp.getG1().newRandomElement().getImmutable();

        Element omega_i= RSUi.add(PID_i.add(Di.add(texti))).getImmutable();
        Element temp1_i=omega_i.add(T3_i).getImmutable();
        byte[] btemp1_i = temp1_i.toBytes();
        int c = Math.max(bhQ1_i.length, btemp1_i.length);
        int d = Math.min(bhQ1_i.length,btemp1_i.length);
        byte[] bM1_i=new byte[n];
        for (int i=0;i<m;i++)
            bM1_i[i]= (byte) (bhQ1_i[i]^btemp1_i[i]);
        Element Gamma2_i=bp.getG1().newRandomElement().getImmutable();
        byte[] bh2_Ri=sha1(omega_i.toString()+X_Ri.toString()+ R_Ri.toString()+T3_i.toString());
        Element h2_Ri=bp.getZr().newElementFromHash(bh2_i,0,bh2_Ri.length).getImmutable();
        byte[] bh3_Ri=sha2(omega_i.toString()+X_Ri.toString()+ R_Ri.toString()+T3_i.toString());
        Element h3_Ri=bp.getZr().newElementFromHash(bh2_i,0,bh3_Ri.length).getImmutable();
        Element sigma_RVi= t3_i.add(h2_Ri.mul(x_Ri).add(h3_Ri.mul(d_Ri)));
        verip.setProperty("h1_"+ID_i,h1_i.toString());
        verip.setProperty("h2_R"+RSU_i,h2_Ri.toString());
        verip.setProperty("h3_R"+RSU_i,h3_Ri.toString());

        Properties certiP=loadPropFromFile(certiFile);
        //Vi验证RSU_i的签名
        Element sigma_RViP=P.powZn(sigma_RVi).getImmutable();
        Element sigmaRViP=T3_i.add(X_Ri.powZn(h2_Ri)).add((R_Ri.add(P_pub.powZn(h1_Ri))).powZn(h3_Ri)).getImmutable();
        if (sigma_RViP.isEqual(sigmaRViP)){
            //若Vi验证成功，保持RSUi为其生成的证书
            certiP.setProperty("T3_"+ID_i,Base64.getEncoder().encodeToString(T3_i.toBytes()));
            certiP.setProperty("sigma_RV_"+ID_i,Base64.getEncoder().encodeToString(sigma_RVi.toBytes()));
            certiP.setProperty("ω_"+ID_i,Base64.getEncoder().encodeToString(omega_i.toBytes()));
            //out.println("RSU验证V成功1");
        }
        else {
            out.println("V验证RSU失败");
        }
        storePropToFile(verip,veriFile);
        storePropToFile(certiP,certiFile);

    }

    public static void crossDomainAKA(String pairingFile,String publicFile,String pkFile,String skFile,String veriFile,String certiFile,String KGC,String RSU_A,String RSU_B,String ID_i,String ID_j) throws NoSuchAlgorithmException {
        //车辆间跨域认证和密钥协商
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub = bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        //获取车辆i,j的假名
        Properties pkp=loadPropFromFile(pkFile);
        String PID_istr=pkp.getProperty("PID_"+ID_i);//获取属性
        Element PID_i=bp.getZr().newElementFromBytes(PID_istr.getBytes()).getImmutable();//字符串转换为element
        String PID_jstr=pkp.getProperty("PID_"+ID_j);//获取属性
        Element PID_j=bp.getZr().newElementFromBytes(PID_jstr.getBytes()).getImmutable();//字符串转换为element

        //获取车辆i,j和其所属域RSU的公钥
        String X_istr=pkp.getProperty("X_"+ID_i);
        Element X_i=bp.getG1().newElementFromBytes(X_istr.getBytes()).getImmutable();
        String R_istr=pkp.getProperty("R_"+ID_i);
        Element R_i=bp.getG1().newElementFromBytes(R_istr.getBytes()).getImmutable();
        String X_Ristr=pkp.getProperty("X_"+RSU_A);
        Element X_Ri=bp.getG1().newElementFromBytes(X_Ristr.getBytes()).getImmutable();
        String R_Ristr=pkp.getProperty("R_"+RSU_A);
        Element R_Ri=bp.getG1().newElementFromBytes(R_Ristr.getBytes()).getImmutable();

        String X_jstr=pkp.getProperty("X_"+ID_j);
        Element X_j=bp.getG1().newElementFromBytes(X_jstr.getBytes()).getImmutable();
        String R_jstr=pkp.getProperty("R_"+ID_j);
        Element R_j=bp.getG1().newElementFromBytes(R_jstr.getBytes()).getImmutable();
        String X_Rjstr=pkp.getProperty("X_"+RSU_B);
        Element X_Rj=bp.getG1().newElementFromBytes(X_Rjstr.getBytes()).getImmutable();
        String R_Rjstr=pkp.getProperty("R_"+RSU_B);
        Element R_Rj=bp.getG1().newElementFromBytes(R_Rjstr.getBytes()).getImmutable();
        //获取车辆i,j和其所属域RSU私钥
        Properties skp=loadPropFromFile(skFile);
        String x_istr=skp.getProperty("x_"+ID_i);
        Element x_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_istr)).getImmutable();
        String d_istr=skp.getProperty("d_"+ID_i);
        Element d_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_istr)).getImmutable();
        String x_Ristr=skp.getProperty("x_"+RSU_A);
        Element x_Ri=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_Ristr)).getImmutable();
        String d_Ristr=skp.getProperty("d_"+RSU_A);
        Element d_Ri=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_Ristr)).getImmutable();

        String x_jstr=skp.getProperty("x_"+ID_j);
        Element x_j=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_jstr)).getImmutable();
        String d_jstr=skp.getProperty("d_"+ID_j);
        Element d_j=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_jstr)).getImmutable();
        String x_Rjstr=skp.getProperty("x_"+RSU_B);
        Element x_Rj=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_Rjstr)).getImmutable();
        String d_Rjstr=skp.getProperty("d_"+RSU_B);
        Element d_Rj=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_Rjstr)).getImmutable();

        //获取车辆i,j各自的证书
        Properties certip=loadPropFromFile(certiFile);
        String T3_istr=certip.getProperty("T3_"+ID_i);
        String sigma_RVistr=certip.getProperty("sigma_RV_"+ID_i);
        String omega_istr=certip.getProperty("ω_"+ID_i);
        Element T3_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(T3_istr)).getImmutable();
        Element sigma_RVi=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(sigma_RVistr)).getImmutable();
        Element omega_i=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(omega_istr)).getImmutable();

        String T3_jstr=certip.getProperty("T3_"+ID_j);
        String sigma_RVjstr=certip.getProperty("sigma_RV_"+ID_j);
        String omega_jstr=certip.getProperty("ω_"+ID_j);
        Element T3_j=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(T3_jstr)).getImmutable();
        Element sigma_RVj=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(sigma_RVjstr)).getImmutable();
        Element omega_j=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(omega_jstr)).getImmutable();

        //V_i向V_j发消息
        Element t_i=bp.getZr().newRandomElement().getImmutable();
        Element tA_i=bp.getZr().newRandomElement().getImmutable();
        Element T_i=P.powZn(t_i).getImmutable();
        Element P_i=P.powZn(tA_i).getImmutable();
        Element Gamma3_i=bp.getG1().newRandomElement().getImmutable();
        byte[] bh4_i=sha1(P_pub.toString()+PID_i.toString()+ X_i.toString()+R_i.toString()+Gamma3_i.toString());
        Element h4_i=bp.getZr().newElementFromHash(bh4_i,0,bh4_i.length).getImmutable();
        byte[] bh5_i=sha2(P_pub.toString()+PID_i.toString()+ X_i.toString()+R_i.toString()+Gamma3_i.toString());
        Element h5_i=bp.getZr().newElementFromHash(bh5_i,0,bh5_i.length).getImmutable();
        Element sigma_Vi= sigma_RVi.add(t_i.add(h4_i.mul(x_i)).add(h5_i.mul(d_i))).getImmutable(); //注意检查计算！
        //
        Properties verip=loadPropFromFile(veriFile);
        String h1_istr=verip.getProperty("h1_"+ID_i);
        String h2_Ristr=verip.getProperty("h2_R"+RSU_A);
        String h3_Ristr=verip.getProperty("h3_R"+RSU_A);
        Element h1_i=bp.getZr().newElementFromBytes(h1_istr.getBytes()).getImmutable();
        Element h2_Ri=bp.getZr().newElementFromBytes(h2_Ristr.getBytes()).getImmutable();
        Element h3_Ri=bp.getZr().newElementFromBytes(h3_Ristr.getBytes()).getImmutable();
        byte[] bh1_Ri=sha1(P_pub.toString()+RSU_A+X_Ri.toString()+ R_Ri.toString());
        Element h1_Ri=bp.getZr().newElementFromHash(bh1_Ri,0,bh1_Ri.length).getImmutable();

        String h1_jstr=verip.getProperty("h1_"+ID_j);
        String h2_Rjstr=verip.getProperty("h2_R"+RSU_B);
        String h3_Rjstr=verip.getProperty("h3_R"+RSU_B);
        Element h1_j=bp.getZr().newElementFromBytes(h1_jstr.getBytes()).getImmutable();
        Element h2_Rj=bp.getZr().newElementFromBytes(h2_Rjstr.getBytes()).getImmutable();
        Element h3_Rj=bp.getZr().newElementFromBytes(h3_Rjstr.getBytes()).getImmutable();
        byte[] bh1_Rj=sha1(P_pub.toString()+RSU_B+X_Rj.toString()+ R_Rj.toString());
        Element h1_Rj=bp.getZr().newElementFromHash(bh1_Rj,0,bh1_Rj.length).getImmutable();

        //Vj验证Vi in 跨域
        Element sigma_ViP = P.powZn(sigma_Vi).getImmutable();

        //Element sigmaRViP1 = T3_i.add(X_Ri.powZn(h2_Ri)).add((R_Ri.add(P_pub.powZn(h1_Ri))).powZn(h3_Ri)).getImmutable();
        Element sigma_RViP=P.powZn(sigma_RVi).getImmutable();
        Element sigmaViP=sigma_RViP.add(T_i.add(X_i.powZn(h4_i)).add(R_i.add(P_pub.powZn(h1_i)).powZn(h5_i))).getImmutable();
        //Element sigmaViP = sigma_RViP.add(T_i.add(X_i.powZn(h4_i))).add((R_i.add(P_pub.powZn(h1_i))).powZn(h5_i)).getImmutable();
//        if(sigma_ViP==sigmaViP){
//            //验证成功
//
//        }
//        else{
//            //out.println("Vj验证Vi失败");
//        }
        Element t_j=bp.getZr().newRandomElement().getImmutable();
        Element tB_j=bp.getZr().newRandomElement().getImmutable();
        Element T_j=P.powZn(t_j).getImmutable();
        Element P_j=P.powZn(tB_j).getImmutable();
        Element Gamma4_j=bp.getG1().newRandomElement().getImmutable();
        byte[] bh4_j=sha1(P_pub.toString()+PID_j.toString()+ X_j.toString()+R_j.toString()+Gamma4_j.toString());
        Element h4_j=bp.getZr().newElementFromHash(bh4_j,0,bh4_j.length).getImmutable();
        byte[] bh5_j=sha2(P_pub.toString()+PID_j.toString()+ X_j.toString()+R_j.toString()+Gamma4_j.toString());
        Element h5_j=bp.getZr().newElementFromHash(bh5_j,0,bh5_j.length).getImmutable();
        Element sigma_Vj= sigma_RVj.add(t_j.add(h4_j.mul(x_j)).add(h5_i.mul(d_j))).getImmutable();
        byte[] bh6_ji=sha1(PID_i.toString()+PID_j.toString()+ P_i.powZn(tB_j).toString()+X_i.add(R_i.add(P_pub.powZn(h1_i))).powZn(x_j.add(d_j)).toString());
        Element SK_ji=bp.getZr().newElementFromHash(bh6_ji,0,bh6_ji.length).getImmutable();
        skp.setProperty("SK_ji",SK_ji.toString());

        //Vi验证Vj in 跨域
        Element sigma_VjP = P.powZn(sigma_Vj).getImmutable();
        //Element sigmaRVjP=T3_j.add(X_Rj.powZn(h2_Rj)).add((R_Rj.add(P_pub.powZn(h1_Rj))).powZn(h3_Rj)).getImmutable();
        Element sigma_RVjP=P.powZn(sigma_RVj).getImmutable();
        Element sigmaVjP = sigma_RVjP.add(T_j.add(X_j.powZn(h4_j))).add((R_j.add(P_pub.powZn(h1_j))).powZn(h5_j)).getImmutable();
//        if(sigma_VjP==sigmaVjP){
//            //验证成功
//        }
//        else{
//            //out.println("Vi验证Vj失败");
//        }

        byte[] bh6_ij=sha1(PID_i.toString()+PID_j.toString()+ P_j.powZn(tA_i).toString()+X_j.add(R_j.add(P_pub.powZn(h1_j))).powZn(x_i.add(d_i)).toString());
        Element SK_ij=bp.getZr().newElementFromHash(bh6_ij,0,bh6_ij.length).getImmutable();
        skp.setProperty("SK_ij",SK_ij.toString());
        storePropToFile(skp,skFile);

    }




    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static byte[] sha2(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-256");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/ours/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String certificateFileName=dir+"certi.properties";
        String verifyFileName=dir+"Veri.properties";
        String KGC = "KGC";
        String RSU_A="RSU_A";
        String RSU_B="RSU_B";
        String ID_i="Vhiclei";
        String ID_j="Vhiclej";

        for (int i=0;i<10;i++){
            //long sta = System.currentTimeMillis();

            //long end = System.currentTimeMillis();
            //out.println(end-sta);
        }
        for (int i = 0; i < 10; i++) {

            setup(pairingParametersFileName,publicParameterFileName,mskFileName,KGC);
            Registration_RSU(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,KGC,RSU_A);
            Registration_RSU(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,KGC,RSU_B);
            long start = System.currentTimeMillis();
            Registration_V(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,KGC,ID_i);
            Registration_V(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,KGC,ID_j);
            long end = System.currentTimeMillis();
            System.out.println(end - start);
            IdAuth_RSU_V_and_getCerti(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,verifyFileName,certificateFileName,KGC,RSU_A,ID_i);
            IdAuth_RSU_V_and_getCerti(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,verifyFileName,certificateFileName,KGC,RSU_B,ID_j);


            //long start = System.currentTimeMillis();
            crossDomainAKA(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,verifyFileName,certificateFileName,KGC,RSU_A,RSU_B,ID_i,ID_j);
            //long end = System.currentTimeMillis();
            //System.out.println(end - start);
        }

        /*  long start1 = System.currentTimeMillis();
            long end1= System.currentTimeMillis();
            System.out.println(end1 - start1);


        */


    }
}
